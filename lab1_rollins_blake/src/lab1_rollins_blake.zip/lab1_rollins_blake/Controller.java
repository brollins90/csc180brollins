package lab1_rollins_blake;

/**
 * Creates the ContactManaer and runs the program
 * @author Blake Rollins
 *
 */
public class Controller {

	public static void main(String[] args) {
		ContactManager m = new ContactManager();
		m.runContactManager();
	}
}
